package smartinternz.challenge.customercareregistry;

public interface MyCompleteListener {
    void onSuccess();
    void onFailure();
}
